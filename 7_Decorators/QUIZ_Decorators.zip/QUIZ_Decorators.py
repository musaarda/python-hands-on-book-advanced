"""
 QUIZ Decorators
"""
# --------------------------------------------------------------------------------------#

# Q 1:
"""
We have a basic function which takes one argument and simply returns it.
Here is this function:
def some_text(text):
    return text
    
We want this function to always return the text in uppercase letters.
For example when we call it as: 
some_text('this is a lowercase text...')
We want it to return 'THIS IS A LOWERCASE TEXT...'.
But we do not want to modify the function body. 
Function definition will not be changed.
What we need is a decorator to do the uppercase conversion for our function.

You need to define this decorator.
Also make sure that, if the function parameter is not a string (str) object, you shouldn't convert it to upper case.

Hints:
* @decorator
* type()
"""

# Q 1:

# define the decorator
# ---- your solution here ---

# decorate the function
# ---- your solution here ---

# call some_text function
# ---- your solution here ---

# print the final text
# ---- your solution here ---


# --------------------------------------------------------------------------------------#

# Q 2:
"""
We want to track the execution time for our functions.
We will use the time module for time tracking.
Remember that time.time() returns the current time in seconds. 
So, if we get the start and end times of execution, we can measure how long the function takes.
We want to define a decorator for this operation.
The  decorator’s name will be time_tracker.
Since it is going to be a general-purpose decorator, we don't know the number of parameters in advance.
We want it to print something like this (after executing the function):
"Function executed in (seconds): 2.0050909519195557"

To test your decorator, simply define a function which sleeps for some seconds.
Here is the function:
def sleeper(seconds):
    time.sleep(seconds)

The sleeper() function just waits for the given number of seconds.
Decorate this function with your decorator and print its execution time.    

Hints:
* @decorator
* *args
* time.time()
"""

# Q 2:

# import time module
# ---- your solution here ---

# define the decorator
# ---- your solution here ---

# decorate function
# ---- your solution here ---

# call the sleeper function to sleep 2 seconds
# ---- your solution here ---

# --------------------------------------------------------------------------------------#

# Q 3:
"""
Define a class decorator named FunctionDetails.
This decorator will print the function details as follows:
* Function Name
* Parameters
* Function Result

Here is the function which we want to decorate:
def full_name(first, last):
    print(first, last)
    
Call the function after you decorate it with FunctionDetails.

Hints:
* __init__
* __call__
* *args
"""

# Q 3:

# define a class decorator
# ---- your solution here ---

# decorate the function
# ---- your solution here ---

# call decorated function
# ---- your solution here ---

# --------------------------------------------------------------------------------------#

# Q 4:
"""
We have a function which simply adds two numbers:
def add_and_multiply(n_1, n_2):
    return n_1 + n_2
    
This function returns the summation of its parameters.
We want to multiply the result of this function with some numbers.
For this, we want to use a decorator.

Define a decorator which multiplies the function result by the given factor.
Decorator name will be multiply_by and it will take one parameter.
Here is the parameter:
* func: function to decorate

The wrapper (inner) function in the decorator will take 3 arguments:
* num_1: first parameter from the function (n_1)
* num_2: second parameter from the function (n_2)
* factor: the number which we want to multiply with
"""

# Q 4:

# define a decorator
# ---- your solution here ---

# decorate function
# ---- your solution here ---

# call the function with n_1, n_2, and factor
add_and_multiply_by_100 = add_and_multiply(4, 7, 100)

# print the result
print(add_and_multiply_by_100)

# --------------------------------------------------------------------------------------#

# Q 5:
"""
Here is a simple decorator:

# functools
import functools
 
# define a decorator with functools
def upper_decorator(func):
    @functools.wraps(func)
    def wrapper(*args):
        # modify the items in *args
        new_args = []
        for i, arg in enumerate(args):
            new_args.append(arg.upper())
        new_args = tuple(new_args)
 
        # return the call to the func
        return func(*new_args)
 
    # return wrapper function
    return wrapper

Why do we need to use @functools.wraps(func) to decorate the wrapper function?
What does it do?
"""

# --------------------------------------------------------------------------------------#