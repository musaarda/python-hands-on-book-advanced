# Class Decorators

# define a class decorator
class ClassDecorator:
    # init method takes the function
    def __init__(self, func):
        self.func = func

    # implement __call__ method
    def __call__(self):
        # some logic before func call
        print('__call__ method before func')
        self.func()
        # Some logic after func call
        print('__call__ method after func')


# add class decorator to func
@ClassDecorator
def say_hi():
    print("Hi Python")

# call the decorated function
# say_hi()


# class decorator with *args & **kwargs
class ClassDecorator:
    def __init__(self, func):
        self.func = func

    def __call__(self, *args, **kwargs):
        # some logic before func call
        self.func(*args, **kwargs)
        # Some logic after func call


# add class decorator to func
@ClassDecorator
def say_hi(first, last, msg='Hi'):
    print("{0} {1} {2}".format(msg, first, last))

# call the decorated function
# say_hi("Bruce", "Wayne", "Hi")


# define a class decorator
class UpperDecorator:
    def __init__(self, func):
        self.func = func

    def __call__(self, *args):
        # modify the items in *args
        new_args = []
        for i, arg in enumerate(args):
            new_args.append(arg.upper())
        new_args = tuple(new_args)

        # return the call to the func
        return self.func(*new_args)

@UpperDecorator
def full_name(first, last):
    print(first, last)

# call decorated function
full_name('jane', 'doe')
