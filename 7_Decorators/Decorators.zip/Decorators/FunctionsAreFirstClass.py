# Functions are First-Class Citizens

# Example 1:
# assign function to a variable
def say_hi(user_name):
    return 'Hi ' + user_name

# assign the function
hi_name = say_hi
# print(hi_name('Bruce Wayne'))


# Example 2:
# Functions can be passed as arguments to other functions.
def print_hello(user):
    print('Hello', user)

def hi_with_function(func, user_name):
    func(user_name)

# call the function
# hi_with_function(print_hello, 'Clark Kent')


# Example 3:
# Functions can return functions
def return_hi_function():
    return say_hi

# call the function
hi = return_hi_function()
# print(hi('Spiderman'))


# Example 4:
# Functions can have other functions in their body
def outer_func(msg):
    """Outer function"""

    # define a nested function
    def inner_func():
        """Inner function"""
        print(msg, 'from nested function.')

    # call the nested function
    inner_func()

# call the outer function
outer_func('The Batman')

