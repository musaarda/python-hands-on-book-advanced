# Decorator Changes the Function Name

# define a general decorator
def upper_decorator(func):
    # wrapper function
    def wrapper(*args):
        # modify the items in *args
        new_args = []
        for i, arg in enumerate(args):
            new_args.append(arg.upper())
        new_args = tuple(new_args)

        # return the call to the func
        return func(*new_args)

    # return wrapper function
    return wrapper

# function without decorator
def last_name(last):
    print(last)

# print function name
# print("Function name before decorator:", last_name.__name__)

# function with decoratoe
@upper_decorator
def last_name(last):
    print(last)

# print function name
# print("Function name after decorator:", last_name.__name__)


# functools
import functools

# define a decorator with functools
def upper_decorator(func):
    @functools.wraps(func)
    def wrapper(*args):
        # modify the items in *args
        new_args = []
        for i, arg in enumerate(args):
            new_args.append(arg.upper())
        new_args = tuple(new_args)

        # return the call to the func
        return func(*new_args)

    # return wrapper function
    return wrapper

# function without decorator
def last_name(last):
    print(last)

# print function name
print("Function name before decorator:", last_name.__name__)

# function with decoratoe
@upper_decorator
def last_name(last):
    print(last)

# print function name
print("Function name after decorator:", last_name.__name__)


