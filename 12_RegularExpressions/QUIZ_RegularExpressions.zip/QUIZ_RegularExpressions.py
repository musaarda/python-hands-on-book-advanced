"""
 QUIZ - Regular Expressions
"""
# --------------------------------------------------------------------------------------#

# Q 1:
"""
Define a regular expression pattern in the following way.
It should:
* start with 3 digits
* first dash (-) after 3 digits
* 4 alphabetical lower case letters (a to z)
* second dash (-)
* one or more word characters after the second dash

Here are some examples:
* "247-abcd-5555"
* "416-dfuy-t"
"""

# Q 1:

# import re module
# ---- your solution here ---

# define the pattern
# ---- your solution here ---

# check match for both examples
# ---- your solution here ---

# print the groups of match objects
# ---- your solution here ---


# --------------------------------------------------------------------------------------#

# Q 2:
"""
Here is the general format for emails:
(user_name)@(domain_name).(top_level_domain)
Write a function named email_validator.
The function will take one parameter which is the email.
It will use a regular expression to validate the given email.
It will return the match object (either an object or None) depending on the email being valid.

Hints:
Some valid email addresses:
* name.lastname@somemail.com
* name_lastname@outlook.com
* johndoe123@yahoo.co.uk

Invalid examples:
* abc_example.com
* xyz123@yahoo
"""

# Q 2:

# import re module
# ---- your solution here ---

# define the function
# ---- your solution here ---

# call the function with valid examples
email = "name.lastname@somemail.com"
print(email_validator(email))

email = "name_lastname@outlook.com"
print(email_validator(email))

email = "johndoe123@yahoo.co.uk"
print(email_validator(email))

# call the function with invalid examples
email = "abc_example.com"
print(email_validator(email))

email = "xyz123@yahoo"
print(email_validator(email))


# --------------------------------------------------------------------------------------#

# Q 3:
"""
Define a function named find_all_with_regex.
The function will take a regular expression and a text as parameters.
Ant will return the list of all possible matches of this regex in the text.
The regex will be: all words starting with 'a' or 'c' (a word must include at least two characters).
The text is:
"Lorem ipsum dolor sit amet, a consectetur adipiscing elit. Sed id cid tempor risus. 
Quisque imperdiet, neque c pulvinar sollicitudin, augue nisl varius nibh, a suscipit cerat non lectus."
"""

# Q 3:

# import re module
# ---- your solution here ---

# define the function
# ---- your solution here ---

# define the text
# ---- your solution here ---

# define regex: find all the words starting with 'a' or 'c'
# ---- your solution here ---

# call the function
# ---- your solution here ---

# print result
# ---- your solution here ---

# --------------------------------------------------------------------------------------#

# Q 4:
"""
Define a function named make_snake_case.
It will take a text as the parameter and will return the snake case form of this text.
Snake case means; replacing all occurrences of space, comma, or dot with an underscore.
Normal text: this is, a text.
Snake case: this_is__a_text_

Hints:
* sub()
"""

# Q 4:

# import re module
# ---- your solution here ---

# define the function
# ---- your solution here ---

# call the function
# ---- your solution here ---

# print the result
# ---- your solution here ---

# --------------------------------------------------------------------------------------#

# Q 5:
"""
Define a function named remove_non_alphanumeric.
It will take a text as the parameter and will return a new modified text.
The function will remove everything except alphanumeric characters from the text.
"""

# Q 5:

# import re module
# ---- your solution here ---

# define the function
# ---- your solution here ---

# call the function
# ---- your solution here ---

# print the result
# ---- your solution here ---


# --------------------------------------------------------------------------------------#