# Match Object

import re

text = "Python 3.0 Deep Learning"
match_obj = re.search(r"\d", text)
# print(match_obj)


# Match.group()
text = "Isaac Newton, physicist"
match_obj = re.search(r"\bN\w+", text)
# print(match_obj.group())


# span()
text = "Isaac Newton, physicist"
match_obj = re.search(r"\bN\w+", text)
# print(match_obj.span())


# Match.string
text = "Isaac Newton, physicist"
match_obj = re.search(r"\bN\w+", text)
print(match_obj.string)

