# re Module

import re

text = 'Hands-On Python Advanced with Coding Exercises'

# call the search method
match = re.search(r'on', text)

# print start and end indices
print('Start Index:', match.start())
print('End Index:', match.end())