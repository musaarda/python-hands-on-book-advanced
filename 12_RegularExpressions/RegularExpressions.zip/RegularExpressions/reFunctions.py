# RE FUNCTIONS

# compile()
import re

text = 'Hands-On Python Advanced with Coding Exercises'

# define the pattern
pattern = r'on'

# compile the regular expression
compiled_re = re.compile(pattern)

# call the search method on the compiled pattern
match = compiled_re.search(text)

# # print start and end indices
# print('Start Index:', match.start())
# print('End Index:', match.end())


# match()
text = 'Hands-On Python Advanced with Coding Exercises'

# define the pattern
pattern = r'on'

# compile the regular expression
compiled_re = re.compile(pattern)

# call the search method on the compiled pattern
match = compiled_re.match(text)

# print start and end indices
# try:
#     print('Start Index:', match.start())
#     print('End Index:', match.end())
# except:
#     print(f"No match found at the beginning of the string for {pattern}")


# split()
text_to_split = 'Words, words, words.'

# split from non-word characters (space, comma, period etc.)
# print(re.split(r'\W+', text_to_split))

# split from non-word characters with maxsplit = 1
# print(re.split(r'\W+', text_to_split, 1))
# ['Words', 'words, words.']

# split from letters a to f and ignore case
# print(re.split('[a-f]+', '0a3B9', flags=re.IGNORECASE))


# findall()
# find words starting with f and have any number of letters (a to z)
# print(re.findall(r'\bf[a-z]*', 'which foot or hand fell fastest'))

# find groups with equal sign between (words and digits)
# print(re.findall(r'(\w+)=(\d+)', 'set width=20 and height=10'))


# finditer()
text = 'python machine leaning is incredible.'
pattern = r'(in)'

# call finditer()
matches = re.finditer(pattern, text)

# print matches
# for match in matches:
#     print(match)


# sub()
text = "Data Science with Python"
replaced_text = re.sub("\s", "_", text)
# print(replaced_text)


txt = "The rain in Spain"
x = re.search(r"\bS\w+", txt)
print(x.group())
