"""
 QUIZ Iterators
"""
# --------------------------------------------------------------------------------------#

# Q 1:
"""
Define an iterator class which will generate a sequence of even numbers like 0, 2, 4, 6, 8, … etc.
Class name will be Even.
Instantiate an object of this class with name even_numbers.
The even_numbers object will be an iterator that provides even numbers from 0 to 20.
Print the even numbers using this object.

Hints:
* __init__()
* __iter__()
* __next__()
"""

# Q 1:

# define the iterator class
# ---- your solution here ---

# instantiate an Odd object
# ---- your solution here ---

# print even numbers
# ---- your solution here ---


# --------------------------------------------------------------------------------------#

# Q 2:
"""
Define an infinite iterator named Counter.
Counter has no terminating condition.
It starts from 10 and keeps increasing by 10 at each iteration.
Instantiate an object of this class with name counter.
The counter object will be an iterator that provides numbers which are multiples of 10.
Print first 5 multiplies of 10 by using the counter object.

Hints:
* __init__()
* __iter__()
* __next__()
"""

# Q 2:

# define the Counter class
# ---- your solution here ---

# create an object
# ---- your solution here ---

# print first 5 numbers
# ---- your solution here ---


# --------------------------------------------------------------------------------------#

# Q 3:
"""
We have a tuple of fruits:
fruits = ("orange", "apple", "cherry")

Convert this tuple to an iterator and print the fruits in it.
Get the StopIteration exception by trying to call the iterator.

Hints:
* iter()
* do not use loops
"""

# Q 3:

# define the tuple
# ---- your solution here ---

# convert tuple to an iterator
# ---- your solution here ---

# print items in the iterator
# ---- your solution here ---

# get StopIteration exception
# ---- your solution here ---


# --------------------------------------------------------------------------------------#

# Q 4:
"""
We have a string object as:
movie = "Inception"

Convert this string to an iterator and print the letters in it.

Hints:
* iter()
* use for loop
"""

# Q 4:

# define the string
# ---- your solution here ---

# convert tuple to an iterator
# ---- your solution here ---

# print items in the iterator
# ---- your solution here ---


# --------------------------------------------------------------------------------------#

# Q 5:
"""
Define a class named Numbers that implements iterator protocol (__iter__ and __next__ methods).
It will return integers starting from 1 and will increase by one at each iteration:
1, 2, 3, 4, 5, ...
Instantiate an object of this class with name numbers.
Convert the numbers object to an iterator.
Print first 4 integers using the numbers object.

Hints:
* no __init__() method in the class
* iter()
* next()
* no for loops
"""

# Q 5:

# define the Numbers class
# ---- your solution here ---

# instantiate the numbers object
# ---- your solution here ---

# convert the numbers object to an iterator
# we have to do this explicitly because
# the Numbers has no __init__() method
# ---- your solution here ---

# print first 4 integers
# ---- your solution here ---


# --------------------------------------------------------------------------------------#