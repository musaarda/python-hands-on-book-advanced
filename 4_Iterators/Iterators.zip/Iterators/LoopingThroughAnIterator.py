# Looping Through an Iterator

# define a list (iterable)
a_list = [10, 20, 30]

# get an iterator from the iterable -> iter()
list_iter = iter(a_list)

# call the next() function
# print(next(list_iter))
# print(next(list_iter))
# print(next(list_iter))

# the following next() call will raise exception
# print(next(list_iter))

# for loop
# for element in a_list:
#     print(element)

# custom for loop implementation
# iterable
my_list = [1, 2, 3]

# iterator from this iterable
list_iter = my_list.__iter__()

# while loop
while True:
    try:
        # next item
        element = list_iter.__next__()
        print(element)
    except StopIteration:
        break
