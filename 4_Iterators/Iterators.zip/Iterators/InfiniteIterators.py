# Infinite Iterators

class InfiniteCounter:
    def __init__(self):
        self.n = 1

    def __iter__(self):
        return self

    def __next__(self):
        current = self.n
        self.n += 1
        return current

# get first four numbers
counter = InfiniteCounter()
print(counter.__next__())
print(counter.__next__())
print(next(counter))
print(next(counter))

