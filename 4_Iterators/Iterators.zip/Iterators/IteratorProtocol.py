# The Iterator Protocol

# define a tuple (iterable)
tup = ("A", "B", "C")
# get an iterator from the iterable -> iter()
tup_iter = iter(tup)

# call the next() function
item_1 = next(tup_iter)
# print(item_1)

# call the next() function
item_2 = next(tup_iter)
# print(item_2)

# call the next() function
item_3 = next(tup_iter)
# print(item_3)


# define a string (iterable)
pyt = 'python'
# get an iterator from the iterable -> iter()
pyt_iter = pyt.__iter__()

# call the next() function
item_1 = pyt_iter.__next__()
# print(item_1)

# call the next() function
item_2 = pyt_iter.__next__()
# print(item_2)

