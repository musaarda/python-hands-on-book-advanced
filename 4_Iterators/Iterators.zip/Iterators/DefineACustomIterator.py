# Define a Custom Iterator

# custom iterator
class Odd:
    # implement __init__ method
    def __init__(self, limit):
        self.current = 1
        self.limit = limit

    # implement __iter__ method
    # simply return the object itself
    def __iter__(self):
        return self

    # implement __next__ method
    def __next__(self):
        # check if limit reached
        if self.current <= self.limit:
            # get the current value
            current_value = self.current
            # increase the current
            self.current += 2
            return current_value
        # limit is reached so raise exception
        else:
            raise StopIteration

# instantiate an Odd object
odd_numbers = Odd(20)

# get first 4 odd numbers
# print(odd_numbers.__next__())
# print(odd_numbers.__next__())
# print(next(odd_numbers))
# print(next(odd_numbers))

# iterate over Odd class
for n in Odd(8):
    print(n)


