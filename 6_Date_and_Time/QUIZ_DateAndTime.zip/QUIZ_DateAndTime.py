"""
 QUIZ Date and Time
"""
# --------------------------------------------------------------------------------------#

# Q 1:
"""
Define two timedelta objects with following attributes:
* object 1: 23 days, 8 hours, 35 minutes
* object 2: 15 days, 6 hours, 50 minutes

Find the difference between these two objects (object 1 - object 2).
Print the result.
"""

# Q 1:

# import timedelta class
# ---- your solution here ---

# define objects
# ---- your solution here ---

# find the difference
# ---- your solution here ---

# print the result
# ---- your solution here ---

# --------------------------------------------------------------------------------------#

# Q 2:
"""
Instantiate a date object using the date() constructor.
The date will be: 
* year: 2017
* month: 6
* day: 5

Replace the day in this date with 24.
Print both dates (the old one and the new one).

Hints:
* date()
* replace()
* replace() will return a new date
"""

# Q 2:

# import date class
# ---- your solution here ---

# create a date object
# ---- your solution here ---

# replace the day
# ---- your solution here ---

# print both dates
# ---- your solution here ---

# --------------------------------------------------------------------------------------#

# Q 3:
"""
Get the following two information from datetime module:
* today's date (today)
* current date and time (now)
Assign them to two variables.

Print the today variable in formats below:
* dd/mm/YY
* mm/dd/y
* month (in text), day and year
* month (abbreviated), day and year

Hints:
* datetime (now)
* date (today)
* strftime()
"""

# Q 3:

# import datetime and date classes
# ---- your solution here ---

# get today
# ---- your solution here ---

# get current date and time
# ---- your solution here ---

# formatting
# dd/mm/YY
# ---- your solution here ---

# mm/dd/y
# ---- your solution here ---

# month (in text), day and year
# ---- your solution here ---

# month (abbreviated), day and year
# ---- your solution here ---

# --------------------------------------------------------------------------------------#

# Q 4:
"""
Create a datetime object corresponding to date string of "%d/%m/%y %H:%M".
Here are the date values:
* year: 2020
* month: 10
* day: 26
* hour: 18
* minutes: 47

Then print the following text by formatting this datetime object:
"Monday, 26. October 2020 06:47PM"

Hints:
* strptime()
* strftime()
"""

# Q 4:

# import datetime class
# ---- your solution here ---

# create a datetime object with strptime()
# ---- your solution here ---

# Format the datetime with strftime()
# ---- your solution here ---

# print the formatted date
# ---- your solution here ---


# --------------------------------------------------------------------------------------#

# Q 5:
"""
Create a date object from ISO format.
The date will be: 2018-11-23

Then print the date in following formats:
* 2018-11-23
* 23/11/18
* Friday 23. November 201

Hints:
* fromisoformat()
* isoformat()
* strftime()
"""

# Q 5:

# import date class
# ---- your solution here ---

# create a date from ISO format
# ---- your solution here ---

# formatted print
# ---- your solution here ---

# --------------------------------------------------------------------------------------#