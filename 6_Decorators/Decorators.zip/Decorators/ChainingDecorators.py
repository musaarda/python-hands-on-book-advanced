# Chaining Decorators

# function for printing symbols
def print_symbol(symbol, times):
    print(symbol * times)

# decorator 1
def plus_sign(f):
    def wrapper(*args, **kwargs):
        print_symbol('+', 20)
        f(*args, **kwargs)
        print_symbol('+', 20)
    return wrapper

# decorator 2
def minus_sign(f):
    def wrapper(*args, **kwargs):
        print_symbol('-', 20)
        f(*args, **kwargs)
        print_symbol('-', 20)
    return wrapper

# chain decorators
@plus_sign
@minus_sign
def say_hi(msg):
    print(msg)

# call the decorated function
# say_hi("Hi Python Developer")


# change the order of chaining
@minus_sign
@plus_sign
def say_hi(msg):
    print(msg)

# call the decorated function
say_hi("Hi Python Developer")

