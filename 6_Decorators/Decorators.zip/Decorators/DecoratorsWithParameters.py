# Decorators with Parameters

# division function
def division(x, y):
    return x / y

# call the function
# result_1 = division(20, 5)
# print(result_1)
#
# result_2 = division(8, 0)
# print(result_2)

# decorator
def division_decorator(f):
    # define the wrapper function
    def wrapper(a, b):
        if b == 0:
            print("Division by zero is not possible.")
            return
        else:
            return f(a, b)

    # return the wrapper function
    return wrapper

# decorate division function
@division_decorator
def division(x, y):
    return x / y

# call the function now
# result_1 = division(20, 5)
# print(result_1)
#
# result_2 = division(8, 0)
# print(result_2)


