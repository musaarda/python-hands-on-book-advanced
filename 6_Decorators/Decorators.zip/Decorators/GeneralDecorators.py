# General Decorators

# define a general decorator
def upper_decorator(func):
    # wrapper function
    def wrapper(*args):
        # modify the items in *args
        new_args = []
        for i, arg in enumerate(args):
            new_args.append(arg.upper())
        new_args = tuple(new_args)

        # return the call to the func
        return func(*new_args)

    # return wrapper function
    return wrapper


@upper_decorator
def first_name(name):
    print(name)

# call first_name function
first_name('john')

@upper_decorator
def full_name(firt, last):
    print(firt, last)

# call the full_name function
full_name('john', 'doe')


# generator with *args and **kwargs
def most_general_decorator(func):
    def wrapper(*args, **kwargs):
        # implement some logic here
        return func(*args, **kwargs)

    return wrapper

