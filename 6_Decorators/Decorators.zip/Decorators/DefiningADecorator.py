# Defining a Decorator

# define a simple decorator
def first_decorator(func):
    def wrapper():
        print("Before running {0} function".format(func.__name__))
        func()
        print("After running {0} function".format(func.__name__))
    return wrapper

def greet():
    print("Hi there")

# call the first_decorator function
greet = first_decorator(greet)

# call the greet function now
# greet()

# greet function object data
# print(greet)


# Decorator Syntax:

# Long Way
# def greet():
#     print("Hi there")

# greet = first_decorator(greet)
# greet()

# Pythonic Way
@first_decorator
def greet():
    print("Hi there")

greet()


