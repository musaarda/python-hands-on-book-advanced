"""
 QUIZ - Database Operations
"""
# --------------------------------------------------------------------------------------#

# Q 1:
"""
Define a function to connect to a MySQL Server and print the connection result.
The function name will be mysql_connect.
It can be the local MySQL Server if you install it on your machine.
If you get an exception, print the error description.
The function will return an active connection object.
"""

# Q 1:

# import mysql
# ---- your solution here ---

# define the function
# ---- your solution here ---

# call the function
# mysql_connect()

# --------------------------------------------------------------------------------------#

# Q 2:
"""
Create a new database named quiz_db.
You should call the connection function which you defined in Q1.
Print the result of the operation, either successful or an exception.

Hints:
* close connection
* close cursor
"""

# Q 2:

# import mysql
# ---- your solution here ---

# function for create the db
# ---- your solution here ---

# call the function and create the db
create_quiz_db("quiz_db")

# --------------------------------------------------------------------------------------#

# Q 3:
"""
Define a function named create_student_table.
It will create a table in the quiz_db database.
The table name will be student.
You should call the connection function which you defined in Q1.

Here are the fields for the student table:
* id: int(11), not null, auto increment and primary key
* first_name: varchar(20)
* last_name: varchar(20)
* age: int(4)

Hints:
* set database as quiz_db on the cursor
* close connection
* close cursor 
"""

# Q 3:

# import mysql
# ---- your solution here ---

# define Student table
# ---- your solution here ---

# connect and create table
# ---- your solution here ---

# call the function
create_student_table()



# --------------------------------------------------------------------------------------#

# Q 4:
"""
Define a function name insert_student_records.
The function will take a list of students and insert them to the student table in db.
We created the student table in quiz_db database in Q3.
You should call the connection function which you defined in Q1.

Here is the list:
students_to_insert = [
    ("Peter", "Parker", 24),
    ("Mary", "Jane", 23),
    ("Clark", "Kent", 32),
    ("Bruce", "Wayne", 29)]
    
Hints:
* commit()
* cursor.executemany() for executing sequences all at once
"""

# Q 4:

# import mysql
# ---- your solution here ---

# define insert query
# ---- your solution here ---

# define student list
# ---- your solution here ---

# connect and insert records
# ---- your solution here ---

# call the function
# ---- your solution here ---



# --------------------------------------------------------------------------------------#

# Q 5:
"""
Define a function named query_students.
It will fetch and print all the student records in the quiz_db database.
You should call the connection function which you defined in Q1.
"""

# Q 5:

# import mysql
# ---- your solution here ---

# query to get all students
# ---- your solution here ---

# connect and set cursor
# ---- your solution here ---

# call the function
query_students()



# --------------------------------------------------------------------------------------#