# Querying Records

# import mysql classes
from mysql.connector import Error

# import custom connection function
from MySQLConnector import connect_to_mysql

# select query to get superheroes
query = ("SELECT * FROM superhero "
         "WHERE hero_name LIKE %s")

name_start_with = 'B%'

# connect and set cursor
def query_records():
    try:
        # connect to server
        connection = connect_to_mysql()
        if connection is not None:
            # set the cursor
            cursor = connection.cursor()
            # execute query with parameters
            cursor.execute(query, (name_start_with,))
            # get the result
            result = cursor.fetchall()
            # print the results
            for row in result:
                print(row)
    except Error as e:
        print(f"An Error occurred in Querying Records:\n'{e}'")
    else:
        cursor.close()
        connection.close()

# call the method to query
query_records()