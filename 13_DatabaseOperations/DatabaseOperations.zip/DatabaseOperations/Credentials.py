# Credentials for local MySQL Server

mysql_host = "localhost"
mysql_user = "root"
mysql_password = "<your_root_password>"