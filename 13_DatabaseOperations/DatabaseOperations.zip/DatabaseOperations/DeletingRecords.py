# Deleting Records
# import mysql classes
from mysql.connector import Error
# import custom connection function
from MySQLConnector import connect_to_mysql
# import UpdatingRecords.py file
import UpdatingRecords

# set the delete query
movie_update_query = ("DELETE FROM movie WHERE movie_id=%s")

# connect and update
def delete_movie(id):
    try:
        # connect to server
        connection = connect_to_mysql()
        if connection is not None:
            # set the cursor
            cursor = connection.cursor()
            # execute query
            cursor.execute(movie_update_query, (id,))
            # commit changes
            connection.commit()
    except Error as e:
        print(f"An Error occurred in Updating Records:\n'{e}'")
    else:
        print(f"Movie with id={id} deleted successfully.")
        cursor.close()
        connection.close()

# delete the movie with id=4
# delete_movie(4)

# get all movies again
UpdatingRecords.get_movies()