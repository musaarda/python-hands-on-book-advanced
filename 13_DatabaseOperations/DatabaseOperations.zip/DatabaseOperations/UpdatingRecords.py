# Updating Records

# import mysql classes
from mysql.connector import Error

# import custom connection function
from MySQLConnector import connect_to_mysql

#--- GET ALL MOVIES ---#
# select query to get all movies
movie_select_query = ("SELECT * FROM movie")

# connect and set cursor
def get_movies():
    try:
        # connect to server
        connection = connect_to_mysql()
        if connection is not None:
            # set the cursor
            cursor = connection.cursor()
            # execute query
            cursor.execute(movie_select_query)
            # get the result
            result = cursor.fetchall()
            # print the results
            for (movie_id, movie_name, release_year) in result:
                print(f"{movie_id}\t{movie_name}\t{release_year}")
    except Error as e:
        print(f"An Error occurred in Querying Records:\n'{e}'")
    else:
        cursor.close()
        connection.close()

# call the method to query
# get_movies()


#--- UPDATE A RECORD ---#
# set the update query
movie_update_query = ("UPDATE movie SET movie_name=%s, "
                      "release_year=2000 WHERE movie_id=%s")

# connect and update
def update_movie(id, name):
    try:
        # connect to server
        connection = connect_to_mysql()
        if connection is not None:
            # set the cursor
            cursor = connection.cursor()
            # execute query
            cursor.execute(movie_update_query, (name, id))
            # commit changes
            connection.commit()
    except Error as e:
        print(f"An Error occurred in Updating Records:\n'{e}'")
    else:
        print(f"{name} updated successfully.")
        cursor.close()
        connection.close()

# update the movie with id=3
# update_movie(3, 'Wonder Woman 1984')

# get all movies again
# get_movies()