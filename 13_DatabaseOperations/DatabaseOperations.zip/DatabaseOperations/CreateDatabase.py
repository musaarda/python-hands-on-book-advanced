# Create a Database

# import connector
import mysql.connector

# import custom connection function
from MySQLConnector import connect_to_mysql

# function for create the db
def create_database(db_name):
    try:
        # connect to server
        connection = connect_to_mysql()
        if connection is not None:
            # set the cursor
            cursor = connection.cursor()
            # create the database
            cursor.execute(f"CREATE DATABASE {db_name}")
    except mysql.connector.Error as e:
        print(f"An Error occurred in DB Creation:\n'{e}'")
    else:
        if connection is not None:
            # close the cursor and the connection
            cursor.close()
            connection.close()
            print("Database created successfully.")

# call the function and create the db
# create_database("heroes")


# check database
def print_databases():
    try:
        # connect to server
        connection = connect_to_mysql()
        if connection is not None:
            # set the cursor
            cursor = connection.cursor()
            # execute query to show dbs
            cursor.execute("SHOW DATABASES")
            # print dbs
            for db in cursor:
                print(db)
    except mysql.connector.Error as e:
        print(f"An Error occurred in DB Creation:\n'{e}'")
    else:
        if connection is not None:
            # close the cursor and the connection
            cursor.close()
            connection.close()

print_databases()
