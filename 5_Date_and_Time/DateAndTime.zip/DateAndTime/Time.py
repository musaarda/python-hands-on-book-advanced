# Time Class

from datetime import time, tzinfo, timedelta

# define a custom class
class TZ1(tzinfo):
     def utcoffset(self, dt):
         return timedelta(hours=1)
     def dst(self, dt):
         return timedelta(0)
     def tzname(self,dt):
         return "+01:00"
     def  __repr__(self):
         return f"{self.__class__.__name__}()"


# create a time object
t = time(12, 10, 30, tzinfo=TZ1())
# print("t:",t)
# print("isoformat:", t.isoformat())
# print("dst:", t.dst())
# print("tzname:", t.tzname())
# print("strftime:", t.strftime("%H:%M:%S %Z"))
# print("format:", 'The {} is {:%H:%M}.'.format("time", t))

# Formatting Examples
from datetime import datetime

# current date & time
current = datetime.now()
print("No formatting", current)

# Weekday short version
weekday_short = current.strftime("%a %-m %y")
print('Weekday Short Version:', weekday_short)

# Weekday
weekday = current.strftime("%A %m %-Y")
print('Weekday:', weekday)

# Hour with PM
pm = current.strftime("%-I %p %S")
print('Hour with PM:', pm)

# Time
common_time = current.strftime("%H:%M:%S")
print('Common Time Representation:', common_time)

