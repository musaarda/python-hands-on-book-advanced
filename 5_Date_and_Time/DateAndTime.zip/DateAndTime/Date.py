# Date Class

from datetime import date

# instantiate a date object: year, month, day
a_valid_date = date(2021, 3, 26)
# print("This is a valid date:", a_valid_date)

# an_ivalid_date = date(2021, 3, 48)
# print("This is an invalid date:", an_ivalid_date)

# current date
current_date = date.today()
# print("Current date is:", current_date)
# print("Current year:", current_date.year)
# print("Current month:", current_date.month)
# print("Current day:", current_date.day)


# fromtimestamp: get datetime from timestamp
date_time_from_timestamp = date.fromtimestamp(1527635439)
# print("Timestamp to datetime:", date_time_from_timestamp)

# isoformat() -> YYYY-MM-DD
iso_formatted_date = date(2002, 12, 4).isoformat()
# print(iso_formatted_date)

# ctime()
date_str = date(2002, 12, 4).ctime()
# print(date_str)

# fromisoformat
date_from_iso_str = date.fromisoformat('2019-12-04')
# print(date_from_iso_str)

# fromordinal() and strftime()
# 730920th day after 1. 1. 0001
d = date.fromordinal(730920)
# print(d)

# Methods related to formatting string output
# print(d.isoformat())
# print(d.strftime("%d/%m/%y"))
# print(d.strftime("%A %d. %B %Y"))


# isocalendar()
iso_date_year_end = date(2003, 12, 29).isocalendar()
# print(iso_date_year_end)

iso_date_year_start = date(2004, 1, 4).isocalendar()
# print(iso_date_year_start)

# replace()
d = date(2002, 12, 31)
d_new = d.replace(day=26)
print("d:", d)
print("d_new:", d_new)