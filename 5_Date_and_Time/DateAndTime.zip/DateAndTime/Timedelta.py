# Timedelta Class

from datetime import timedelta

delta = timedelta(
     days=50,
     seconds=27,
     microseconds=10,
     milliseconds=29000,
     minutes=5,
     hours=8,
     weeks=2
 )
# Only days, seconds, and microseconds remain
# print("Days:", delta.days)
# print("Seconds:", delta.seconds)
# print("Microseconds:", delta.microseconds)

# Add two timedelta objects
delta1 = timedelta(minutes=10, seconds=50)
delta2 = timedelta(hours=25, seconds=20)
delta_sum = delta1 + delta2
print(delta_sum)

