# Datetime Class

from datetime import datetime

# call the constructor
datetime_obj = datetime(2020, 5, 29)
# print(datetime_obj)

# call the constructor with time parameters
datetime_obj_with_time = datetime(2020, 5, 29, 8, 45, 52, 162420)
# print(datetime_obj_with_time)

# get attributes
dt = datetime(2019, 8, 17, 23, 38, 54)
# print("Year:", dt.year)
# print("Month:", dt.month)
# print("Day:", dt.day)
# print("Hour:", dt.hour)
# print("Minute:", dt.minute)
# print("Seconds:", dt.second)
# print("Timestamp:", dt.timestamp())

# now()
current_date_time = datetime.now()
# print("Current date & time:", current_date_time)

# examples
from datetime import datetime, date, time, timezone

# Using datetime.combine()
d = date(2005, 7, 14)
t = time(12, 30)
combined_dt = datetime.combine(d, t)
# print(combined_dt)

# Using datetime.now()
# GMT +1
now = datetime.now()
# print(now)

# with timezone info
now_tz = datetime.now(timezone.utc)
# print(now_tz)

# Using datetime.strptime()
dt = datetime.strptime("21/11/06 16:30", "%d/%m/%y %H:%M")
# print(dt)

# Using datetime.timetuple() to get tuple of all attributes
tt = dt.timetuple()
# for it in tt:
#      print(it)

# Date in ISO format
ic = dt.isocalendar()
# for it in ic:
#      print(it)


# Formatting a datetime
formatted_dt = dt.strftime("%A, %d. %B %Y %I:%M%p")
print(formatted_dt)

dt_str = 'The {1} is {0:%d}, the {2} is {0:%B}, the {3} is {0:%I:%M%p}.'.format(dt, "day", "month", "time")
print(dt_str)








