### Counter

from collections import Counter

# a new, empty counter
c1 = Counter()
# print(c1)

# a new counter from an iterable
c2 = Counter('aabbbcddeeee')
# print(c2)

# a new counter from a mapping
c3 = Counter({'orange': 6, 'red': 3, 'green': 5})
# print(c3)

# a new counter from keyword args
c4 = Counter(cats=4, dogs=8)
# print(c4)

# count of existing element
c5 = Counter(['eggs', 'ham', 'jar', 'ham'])
# print(c5['ham'])

# count of a missing element is zero
# print(c5['bacon'])

# --- Delete Elements from a Counter --- #
# counter entry with a zero count
c5['sausage'] = 0
# print(c5)

# del actually removes the entry
del c5['sausage']
# print(c5)


# --- Counter Methods --- #
# elements()
counter = Counter(a=1, b=2, c=0, d=-2, e=4)
sorted_elements = sorted(counter.elements())
# print(sorted_elements)

# most_common()
most_common_3 = Counter('abracadabra').most_common(3)
# print(most_common_3)

# subtract()
c_1 = Counter(a=4, b=2, c=0, d=-2)
c_2 = Counter(a=1, b=2, c=3, d=4)
c_1.subtract(c_2)
# print(c_1)

# update()
d = Counter(a=3, b=1)
d.update({'a': 5, 'c': 4})
# print(d)

