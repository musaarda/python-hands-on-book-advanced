# UserList

from collections import UserList

# define a custom class
# this class will inherit from UserList
# it will not allow its items to be deleted
# List class in Python has to methods for delete:
# remove() and pop()
class ListWithNoItemDelete(UserList):
    # override remove() method
    def remove(self, s=None):
        self.not_allowed()

    # override pop() method
    def pop(self, s=None):
        self.not_allowed()

    def not_allowed(self):
        raise RuntimeError("Deletion not allowed")

# custom list object
custom_list = ListWithNoItemDelete(['a', 'b', 'c'])

# try to delete an item
custom_list.remove('b')

