# OrderedDict

from collections import OrderedDict

od = OrderedDict.fromkeys('abcde')
od.move_to_end('b')
# print(''.join(od))
# 'acdeb'
od.move_to_end('b', last=False)
# print(''.join(od))
# 'bacde'

# delete and re-insert same key
d = OrderedDict()
d['x'] = 'X'
d['y'] = 'Y'
d['z'] = 'Z'

print('OrderedDict before deleting')
for key, value in d.items():
    print(key, value)

# delete the element
d.pop('x')

# re-insert the same key
d['x'] = 'X'

print('\nOrderedDict after insertion')
for key, value in d.items():
    print(key, value)

