### DefaultDict

from collections import defaultdict

s = [('yellow', 1), ('blue', 2), ('yellow', 3), ('blue', 4), ('red', 1)]
d = defaultdict(list)
for k, v in s:
    d[k].append(v)

sorted_items = sorted(d.items())
# print(sorted_items)

river = 'mississippi'
dd = defaultdict(int)
for r in river:
    dd[r] += 1

s_items = sorted(dd.items())
# print(s_items)
