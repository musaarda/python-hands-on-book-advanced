# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    # import modules to run the code in them
    # import ChainMap
    # import Counter
    # import Deque
    # import DefaultDict
    # import NamedTuple
    # import OrderedDict
    # import UserDict
    # import UserList
    import UserString
