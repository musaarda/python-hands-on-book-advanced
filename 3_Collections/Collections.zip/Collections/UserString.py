# UserString

from collections import UserString

# define a custom class
# this class will inherit from UserString
class CustomStrClass(UserString):
    # define a new method
    def concatenate(self, other=None, delimiter=' '):
        self.data += delimiter + other

# custom string object
custom_str = CustomStrClass('My Custom')
custom_str.concatenate('String Class')
print(custom_str)
