# UserDict

from collections import UserDict

us = {'name': 'John Doe', 'age': 24}

# Create UserDict object
ud = UserDict(us)
# print(ud.data)

# class for our custom dict
# inherit from UserDict
class AddEnabledDict(UserDict):
    # override the __add__ method
    def __add__(self, other):
        d = AddEnabledDict(self.data)
        d.update(other.data)
        return d

# create custom objects
d_1 = AddEnabledDict(x = 10)
d_2 = AddEnabledDict(y = 20)
total = d_1 + d_2
# print(total)

