### NamedTuple

from collections import namedtuple

# Declare the namedtuple
Employee = namedtuple('Employee', ['id', 'name', 'age'])

# Add some values to the tuple
E_1 = Employee('111', 'Peter Parker', '18')
E_2 = Employee('222', 'Clark Kent', '26')

# Access using index
# print("Employee name by index is : ", end="")
# print(E_1[1])

# Access using keys
# print("Employee name using key is : ", end="")
# print(E_2.name)

# _make()
# initialize an iterable
bat_data = ['333', 'Batman', '28']
batman = Employee._make(bat_data)
# print(batman)

# _asdict()
bat_dict = batman._asdict()
# print(bat_dict)

# _replace()
batman = batman._replace(id='777', age='34')
# print(batman)

# _fields
# print(batman._fields)

# namedtuple fields from others
Point = namedtuple('Point', ['x', 'y'])
Color = namedtuple('Color', 'red green blue')
Pixel = namedtuple('Pixel', Point._fields + Color._fields)
p = Pixel(5, 8, 128, 255, 0)
# print(p)
