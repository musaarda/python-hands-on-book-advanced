### Deque

from collections import deque

# Declaring the deque
q = deque(['user', 'password', 'token'])
# print(q)

# make a new deque with three items
d = deque('dqi')
# iterate over the deque's elements
# for elem in d:
#     print(elem.upper())

# list the contents of the deque
deque_contents = list(d)
# print(deque_contents)

# peek at leftmost item
# print(d[0])

# peek at rightmost item
# print(d[-1])

# add a new entry to the right side
d.append('j')

# add a new entry to the left side
d.appendleft('f')

# show the representation of the deque
# print(d)

# return and remove the rightmost item
rightmost = d.pop()
# print(rightmost)

# return and remove the leftmost item
leftmost = d.popleft()
# print(leftmost)

# add multiple elements at once
d.extend('jkl')
# print(d)

# extendleft() reverses the input order
d.extendleft('xyz')
# print(d)

# deque at the beginning
# print(d)

# right rotation
d.rotate(1)
# print(d)

# left rotation
d.rotate(-1)
# print(d)

# deque at the beginning
print('old deque:', d)

# reverse the elements in the deque
new_deq = d.reverse()
print('new deque:', new_deq)

# original deque after reversed()
print('old deque:', d)

