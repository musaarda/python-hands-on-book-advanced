### ChainMap

# import ChainMap class from collections module
from collections import ChainMap

#--- Defining a ChainMap ---#
numbers = {'one': 1, 'two': 2}
letters = {'a': 'A', 'b': 'B'}

# Define the ChainMap
chain_map = ChainMap(numbers, letters)

# print(chain_map)


#--- Accessing Keys and Values from ChainMap ---#
# print(chain_map.keys())
# print(chain_map.values())

#--- Accessing Individual Values with Key Names ---#
# print(chain_map['one'])
# print(chain_map['b'])

#--- Adding a New Dictionary to ChainMap ---#
variables = {'x': 0, 'y': 1}
new_chain_map = chain_map.new_child(variables)
# print('Old:', chain_map)
# print('New:', new_chain_map)

#--- Get the List of Mappings in ChainMap ---#
# print(chain_map.maps)
