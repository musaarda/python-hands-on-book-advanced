"""
 QUIZ Collections
"""
# --------------------------------------------------------------------------------------#

# Q 1:
"""
Here are three dictionaries:
letters = {'a': 'A', 'b': 'B', 'c': 'C'}
numbers = {1: 1000, 2: 2000, 3: 3000}
fruits = {'orange': 300, 'apple': 500}

Define a ChainMap by using letters and numbers dictionaries.
The name of the ChainMap will be my_map.
Print the maps in my_map.
Print all of the keys and values in my_map as: "Key : Value".
Add fruits dictionary to the my_map.
Print the maps in this new ChainMap.
Print all of the keys and values in this new ChainMap as: "Key : Value".

Hints:
* new_child() 
* new_child() will return a new ChainMap
"""

# Q 1:

# import ChainMap
# ---- your solution here ---

# dictionaries
# ---- your solution here ---

# define the ChainMap
# ---- your solution here ---

# print maps
# ---- your solution here ---

# print key: value pairs
# ---- your solution here ---

# add fruits dictionary
# ---- your solution here ---

# print maps
# ---- your solution here ---

# print key: value pairs
# ---- your solution here ---

# --------------------------------------------------------------------------------------#

# Q 2:
"""
Here is some text:
'''Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
Quisque bibendum sodales ipsum in lacinia. 
Morbi metus dui, venenatis ut molestie a, porta sit amet est. 
Maecenas sagittis turpis nec nisl tempus consequat.'''

Define a Counter which will store all the characters 
and their respective counts in this text.

Print the most common 5 characters in the text.

Hints:
* Counter
* most_common()
* we don't want to count the space character
"""

# Q 2:

# import Counter class
from collections import Counter

# define the text
# ---- your solution here ---

# remove the space character
# ---- your solution here ---

# define the Counter
# ---- your solution here ---

# print most common 5 characters
# ---- your solution here ---

# --------------------------------------------------------------------------------------#

# Q 3:
"""
Create a deque object with name my_deque.
my_deque will have first four letters in the alphabet: a, b, c, d.
Extend this deque from the left by adding three more letters: e, f, g.
Print the items in my_deque.
Create a new deque (new_deque) using my_deque.
new_deque will be the reverse of my_deque.
Print the items in new_deque.
Please be careful that, my_deque object will not be modified.

Hints:
* deque
* extendleft()
* reverse()
"""

# Q 3:

# import Deque class
# ---- your solution here ---

# define a new deque
# ---- your solution here ---

# extend my_deque from left
# ---- your solution here ---

# print items in my_deque
# ---- your solution here ---

# copy my_deque
# ---- your solution here ---

# reverse my_deque
# ---- your solution here ---

# print items in new_deque
# ---- your solution here ---


# --------------------------------------------------------------------------------------#

# Q 4:
"""
We have a long word in English: incomprehensibilities.
We want to count occurrences of each letter in this word.
Print the most common three letters in this word.

Hints:
* use defaultdict
* default_factory
* do not use Counter
"""


# Q 4:

# import defaultdict
# ---- your solution here ---

# define the text
# ---- your solution here ---

# define the defaultdict
# ---- your solution here ---

# fill the defaultdict
# ---- your solution here ---

# sort items in the defualtdict
# by number of occurrences in decreasing order
# ---- your solution here ---

# print the most common 3 words
# ---- your solution here ---

# --------------------------------------------------------------------------------------#

# Q 5:
"""
Define a namedtuple as SuperHero.
SuperHero has three attributes:
* hero_name
* real_name
* age
Create two SuperHero instance as follows:
* Spiderman, Peter Parker, 18
* Superman, Clark Kent, 26

Print the real names of SuperHeroes using keys as follows:
* Real name of Spiderman is: Peter Parker
* Real name of Superman is: Clark Kent

Hints:
* namedtuple
* attributes are keys as: namedtuple.key
"""

# Q 5:

# import namedtuple
# ---- your solution here ---

# Declare the namedtuple
# ---- your solution here ---

# Create SuperHero instances
# ---- your solution here ---

# Access using key
# ---- your solution here ---

# --------------------------------------------------------------------------------------#