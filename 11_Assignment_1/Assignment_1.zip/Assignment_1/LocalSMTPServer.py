# import modules and packages
# TODO - import smtplib module
# TODO - import EmailMessage class from email.message

# define email attributes
# TODO - define subject variable
# TODO - define sender variable
# TODO - define receiver variable

# define email object
# TODO - instantiate an EmailMessage object

# set headers
# TODO - set headers for EmailMessage object
# - Subject
# - From
# - receiver

# set body text
# TODO - set content for EmailMessage object

# define port
# TODO - define the port as 1025

# call smtplib.SMTP in the with context manager
# TODO - set a with context manager for local server
#      by calling the related class in the smtplib module
# TODO - send the message
# TODO - print the final text for success
