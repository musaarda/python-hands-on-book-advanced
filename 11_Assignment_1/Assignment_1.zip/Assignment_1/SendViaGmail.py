# Sending Emails via Gmail
# TODO - import modules and classes
#       - smtplib module
#       - MIMEMultipart, MIMEText

# TODO - set server and port
#       - "smtp.gmail.com"
#       - 587 (for STARTTLS connection)

# TODO - set some content

# TODO - set mail addresses and password
#       - sender, password, receiver

# TODO - create a message object with MIMEMultipart

# TODO - set Subject, From, To attributes of message object

# TODO - set the body by attaching the content to message

# TODO - create SMTP session

# TODO - enable security (starttls)

# TODO - login to the session with credentials

# TODO - convert message to string before sending

# TODO - send the email on the session

# TODO - quit the session
