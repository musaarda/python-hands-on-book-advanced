# Sending HTML Email

# TODO - import smtplib and email.mime classes
#        MIMEText and MIMEMultipart

# TODO - define the port on 2525

# TODO - define SMTP server for mailtrap

# TODO - set login credentials

# TODO - set sender and receiver emails

# TODO - create a message object from MIMEMultipart

# TODO - set Subject, From, To attributes of message object

# --- PLAIN TEXT PART ---
# TODO - set a with context manager to read "files/plain_text_part.txt"
#        assign the content to a variable called text

# --- HTML PART ---
# TODO - set a with context manager to read "files/html_part.txt"
#        assign the content to a variable called html

# TODO - convert both parts to MIMEText objects
#       "plain" and "html"

# TODO - add the parts to the MIMEMultipart message

# TODO - set a with context manager to call the SMTP class
#        with mailtrap server and port
# TODO - write a try-except-else block,
#        login to the server and send the email
#        print a success message in the end


