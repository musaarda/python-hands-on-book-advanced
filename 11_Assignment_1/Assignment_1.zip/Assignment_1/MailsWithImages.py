# Sending Emails with Images
# TODO - import the necessary components first
#       - smtplib module
#       - MIMEText, MIMEMultipart
#       - base64

# TODO - set server and port

# TODO - set login credentials by Mailtrap

# TODO - set sender and receiver emails

# TODO - create a message object with MIMEMultipart

# TODO - set Subject, From, To attributes of message object

# TODO - read and encode the image file at "images/python_logo.jpeg"

# TODO - define html content with an f-string
#       - having an img tag in it with src as your image

# TODO - create a MIMEText part with MIME type as html

# TODO - attach the part to the message

# TODO - set a with context manager to call the SMTP class
#        with mailtrap server and port
# TODO - write a try-except-else block,
#        login to the server and send the email
#        print a success message in the end


