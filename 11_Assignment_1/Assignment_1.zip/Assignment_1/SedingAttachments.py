# Sending Attachments with Email
# TODO - import modules and classes
#       - smtplib, encoders, MIMEBase, MIMEMultipart, MIMEText

# TODO - set server and port

# TODO - set login credentials by Mailtrap

# TODO - set sender and receiver emails

# TODO - create a message object with MIMEMultipart

# TODO - set Subject, From, To attributes of message object

# TODO - set email body

# TODO - attach email body to the message

# TODO - set file info (file path and file name)

# TODO - open the PDF file in read-binary mode
# TODO - set application of the MIMEBase class
# TODO - set payload to attachment content

# TODO - encode the message part to base64

# TODO - Add mail header
#       - Content-Disposition,
#       - attachment; filename=

# TODO - Add attachment to the message

# TODO - convert message it to string

# TODO - set a with context manager to call the SMTP class
#        with mailtrap server and port
# TODO - write a try-except-else block,
#        login to the server and send the email
#        print a success message in the end
