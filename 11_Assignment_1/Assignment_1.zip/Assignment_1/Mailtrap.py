# send email to Mailtrap fake server

# TODO - import smtplib module

# TODO - define sender and receiver variables

# TODO - set the message object with an f-string

# TODO - set a with context manager to call the SMTP class
#        with mailtrap server and port
# TODO - write a try-except-else block,
#        login to the server and send the email
#        print a success message in the end

