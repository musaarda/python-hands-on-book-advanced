# Function Based Context Managers

from contextlib import contextmanager

# define the context manager function
@contextmanager
def function_based_context_manager():
    print("Entering the context: __enter__")
    yield "This is a function based context manager"
    print("Leaving the context: __exit__")

# use context manager function in with statement
# with function_based_context_manager() as yield_text:
#     print(yield_text)



# context manager for write operations
from contextlib import contextmanager

@contextmanager
def writer_context_manager(path, mode='w'):
    file_object = None
    try:
        file_object = open(path, mode=mode)
        yield file_object
    finally:
        if file_object:
            file_object.close()

# context manager in with statement
with writer_context_manager("function_based_context_managers.txt") as file:
    file.write("The contextlib.contextmanager decorator \n"
               "is responsible for implementing the\n"
                "context manager protocol.")

