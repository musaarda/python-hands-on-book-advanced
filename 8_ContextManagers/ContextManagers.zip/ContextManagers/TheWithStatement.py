# The with Statement

# with expression as result_variable:
#     # do something
#     # using the result_variable

# define the file path
path = 'files/color_names.txt'

# with statement
with open(path, mode='r') as file:
    # read the file content
    print(file.read())


