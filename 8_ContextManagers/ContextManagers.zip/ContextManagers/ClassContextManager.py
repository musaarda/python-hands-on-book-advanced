# Creating a Context Manager in Class Form

# custom context manager class
class CustomContexManager:
    # init method -> define variables
    def __init__(self, path, mode):
        self.path = path
        self.mode = mode
        self.file = None

    # __enter__ method -> open the file
    def __enter__(self):
        self.file = open(self.path, self.mode)
        return self.file

    # exit method to close the file
    def __exit__(self, exc_type, exc_value, exc_traceback):
        self.file.close()


# custom contex manager in with statement
file_path = 'files/color_names.txt'

# with CustomContexManager(path=file_path, mode='r') as file:
#     # print the file content
#     print(file.read())




# context manager for listing files
import os

class ContentList:
    '''Prints the content of a directory'''

    def __init__(self, directory):
        self.directory = directory

    def __enter__(self):
        return os.listdir(self.directory)

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type is not None:
            print("Error getting directory list.")
        return True

# print the contents of the project directory
project_directory = '.'
with ContentList(project_directory) as directory_list:
    print(directory_list)

