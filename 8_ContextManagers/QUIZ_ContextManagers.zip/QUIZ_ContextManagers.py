"""
 QUIZ Context Managers
"""
# --------------------------------------------------------------------------------------#

# Q 1:
"""
Define a custom context manager class as MyContextManager.
Define the __init__, __enter__ and __exit__ methods.
Your context manager should open and return the file object at specified path.
Also it should close the file on exit.
The parameters to the __init__ method should be:
* path: file path for the file to read
* mode: operation mode (read, write, append etc.)

Read and print the file content at "files/color_names.txt".

Hints:
* __init__
* __enter__
* __exit__
"""

# Q 1:

# define custom context manager class
# ---- your solution here ---

# define the file path as "files/color_names.txt"
file_path = 'files/color_names.txt'

# read and print the content of the file at this path
# ---- your solution here ---

# --------------------------------------------------------------------------------------#

# Q 2:
"""
Define a context manager class to get the list of folders in a directory.
The name will be FoldersInDirectory and it will return only the folder names in a specified directory.
The class constructor will take the directory path as the parameter.
Make sure, you implement __enter__ and __exit__ methods properly.

Print the folder list by using a with statement.

Hints:
* __init__
* __enter__
* __exit__
"""

# Q 2:

# import os module
# ---- your solution here ---

# context manager for listing folders
# ---- your solution here ---

# define the directory path as current directory
# ---- your solution here ---

# print the folders in the project directory
# using a with statement
# ---- your solution here ---


# --------------------------------------------------------------------------------------#

# Q 3:
"""
Define a function based context manager which creates a file and writes some text in it.
The name will be file_writer and it will take two parameters:
* path: file path for the file to read
* mode: operation mode (read, write, append etc.)

Use this context manager in a with statement to create a file and add the text below in this file.
File name should be: "quiz_text_file_for_writing.txt".
And the text is:
"The file is created by quiz question number 3.
It is a function-based context manager,
Decorated with contextlib.contextmanager."

You should see "quiz_text_file_for_writing.txt" file after you run the code in this question.

Hints:
* contextlib.contextmanager
* try-finally
"""

# Q 3:

# import contextmanager class
# ---- your solution here ---

# context manager for write operations
# define and decorate
# ---- your solution here ---


# context manager in with statement
# ---- your solution here ---

# --------------------------------------------------------------------------------------#

# Q 4:
"""
Define a function-based context manager named sleeper_context_manager.
It will print the following data:
* Start time: Time at start of its execution
* End time: Time at end of its execution
* Execution time in seconds: Difference between end time and start time

Use this context manager in a with statement.
You should wait for 2 seconds in the with statement body.
And you should print something similar to this:
"Start time: 1649346091.427541
End time: 1649346093.432682
Execution time in seconds: 2.005141019821167"

The start time and end time will change when you run the code.
But the execution time should be around 2.00 seconds.

Hints:
* contextlib.contextmanager
* yield nothing
* time.sleep()
"""

# Q 4:

# import contextmanager class and time module
# ---- your solution here ---

# define and decorate the context manager
# ---- your solution here ---

# use the context manager in a with statement
# ---- your solution here ---

# --------------------------------------------------------------------------------------#

# Q 5:
"""
What are the methods in the Context Manager Protocol?
And what are their functionalities?
"""

# --------------------------------------------------------------------------------------#