# hi.py file

# import Flask class from flask package
from flask import Flask

# create a Flask app
app = Flask(__name__)

# define a root
@app.route('/hi')
def hi_flask():
    return "Hi from Flask App"

