# quotes_spider.py file

from scrapy import Spider, Request

class QuotesSpider(Spider):
    # unique identifier of this spider
    name = "quotes"

    # begin crawl and return an iterable
    def start_requests(self):
        urls = [
            'https://quotes.toscrape.com/page/1/',
            'https://quotes.toscrape.com/page/2/',
        ]
        for url in urls:
            # TODO - yield Request objects

    # callback method to handle responses
    def parse(self, response):
        # get the page number from response
        page = # TODO - get page number from response.url
        # create a filename as quotes-1.html
        filename = f'quotes-{page}.html'
        # write into this file
        with open(filename, 'wb') as f:
            # TODO - write the response body
        # log the activity
        self.log(f'Saved file {filename}')


# redefine the same spider with start_urls
class QuotesSpider(Spider):
    # unique identifier of this spider
    name = # TODO - define a unique name for spider
    # start_urls for url list to crawl automatically
    start_urls = # TODO - define urls list

    # callback method to handle responses
    def parse(self, response):
        # get the page number from response
        page = # TODO - get page number from response.url
        # create a filename as quotes-1.html
        filename = # TODO - create a page name
        # write into this file
        with # TODO - open filename in write binary mode:
            # TODO - write the response body

