# quote_spider_follow_links.py file

from scrapy import Spider, Request

class QuoteSpiderFollowLinks(Spider):
    # unique identifier of this spider
    name = # TODO - define a unique name for spider
    # start_urls for url list to crawl automatically
    start_urls = # TODO - define urls list

    # callback method to handle responses
    def parse(self, response):
        # get the div elements with class name quote
        for quote in  # TODO - get div elements with class 'quote' in response:
            # yield a quote dictionary
            yield {
                'text':  # TODO - get the text attribute of
                # span elements with class "text"
                    'author':  # TODO - get the text attribute of
            # small elements with class "author"
            'tags': quote.css('div.tags a.tag::text').getall()
            }

        # get next page element via the href attribute
        next_page = # TODO - get next page element via the href attribute
                    # find li with class "next" and the <a> tag in it
        if next_page is not None:
            # create the next page url
            next_page = response.urljoin(next_page)
            # request the next page with Scrapy Request
            # TODO - yield the Request object


####  response.follow()  ###
class QuoteSpiderFollowLinks(Spider):
    # unique identifier of this spider
    name =  # TODO - define a unique name for spider
    # start_urls for url list to crawl automatically
    start_urls =  # TODO - define urls list

    # callback method to handle responses
    def parse(self, response):
        # get the div elements with class name quote
        for quote in response.css('div.quote'):
            # yield a quote dictionary
            yield {
                'text':  # TODO - get the text attribute of
                # span elements with class "text"
                    'author':  # TODO - get the text attribute of
            # small elements with class "author"
            'tags': quote.css('div.tags a.tag::text').getall()
            }
        # get next page element via the href attribute
        next_page = # TODO - get next page element via the href attribute
        if next_page is not None:
            # TODO - yield a Request object with response.follow()


