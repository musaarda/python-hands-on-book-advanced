# quote_spider_extractor.py file

# TODO - import Spider and Request classes
#  from scrapy package

class QuoteSpiderExtractor(Spider):
    # unique identifier of this spider
    name =  # TODO - define a unique name for spider
    # start_urls for url list to crawl automatically
    start_urls = # TODO - define urls list

    # callback method to handle responses
    def parse(self, response):
        # get the div elements with class name quote
        for quote in # TODO - get div elements with class 'quote' in response:
            # yield a quote dictionary
            yield {
                'text': # TODO - get the text attribute of
                        # span elements with class "text"
                'author': # TODO - get the text attribute of
                          # small elements with class "author"
                'tags': quote.css('div.tags a.tag::text').getall()
            }


