# ThreadPoolExecutor_Map.py file

import requests
import shutil
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
import Utils

# call the function and fill movies
movies = Utils.read_csv()

# create a threads list
threads = []

# function to download a single image
def download_image(movie):
    title = movie['Title']
    file_name = 'images/' + str(title) + '.jpg'
    response = requests.get(movie['ImageURL'], stream=True)
    if response.status_code == 200:
        with open(file_name, 'wb') as file:
            shutil.copyfileobj(response.raw, file)
        print(f"{title} downloaded.")
    else:
        print(f"Error in downloading {title}")

# function to download images
def downlaod_all_images():
    # set start time
    start = time.perf_counter()
    # set ThreadPoolExecutor
    with ThreadPoolExecutor(max_workers=4) as executor:
        # map the threads
        executor.map(download_image, movies)
    # set end time
    end = time.perf_counter()
    # print elapsed time
    print(f"\nDownload took {end-start:.2f} sec, ThreadPoolExecutor.")

# download all images
downlaod_all_images()