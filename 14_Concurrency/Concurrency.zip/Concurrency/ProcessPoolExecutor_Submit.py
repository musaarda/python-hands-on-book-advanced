# ProcessPoolExecutor_Submit.py file

from concurrent.futures import ProcessPoolExecutor, as_completed
import time

# some numbers
primes = [7774777, 7778777, 111181111, 111191111, 777767777]

# function to check for being prime
def is_prime(num):
    if num > 1:
        for n in range(2, num):
            if (num % n) == 0:
                return False
        return True
    else:
        return False

def single_process_check():
    # set start time
    start = time.perf_counter()
    # check the primes list one by one
    for num in primes:
        print(f"Is Prime {num} - {is_prime(num)}")
    # set end time
    end = time.perf_counter()
    # print elapsed time
    print(f"\nTook {end - start:.2f} sec, Single Process.")

# call the single process check
# single_process_check()

### MULTIPROCESSING ###
def multi_proces_check():
    # set start time
    start = time.perf_counter()
    # set ProcessPoolExecutor
    with ProcessPoolExecutor() as executor:
        # submit the threads and get a list of futures
        future_list = [executor.submit(is_prime, n)
                       for n in primes]
        for num, future in zip(primes, as_completed(future_list)):
            print(f"Is Prime {num} - {future.result()}")
    # set end time
    end = time.perf_counter()
    # print elapsed time
    print(f"\nTook {end - start:.2f} sec, Multi Process.")

