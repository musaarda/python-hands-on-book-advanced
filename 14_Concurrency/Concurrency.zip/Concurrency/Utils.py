# Utils.py file

import csv

# define a movies list
movies = []

# function to read movies
def read_csv():
    """reads the csv file and returns
        the list of movies"""
    movie_path = 'data/imdb_top_20.csv'
    with open(movie_path, 'r') as file:
        movie_dict = csv.DictReader(file, delimiter=';')
        for movie in movie_dict:
            movies.append(movie)
    # return the list
    return movies


