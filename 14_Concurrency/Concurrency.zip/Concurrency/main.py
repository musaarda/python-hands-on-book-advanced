# main.py file

import ProcessPoolExecutor_Submit
import ProcessPoolExecutor_Map

if __name__ == '__main__':
    # call multi process check with submit()
    # ProcessPoolExecutor_Submit.multi_proces_check()

    # call multi process check with map()
    ProcessPoolExecutor_Map.multi_proces_check()
