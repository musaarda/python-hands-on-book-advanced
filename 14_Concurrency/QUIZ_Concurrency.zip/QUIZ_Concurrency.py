"""
 QUIZ - Concurrency
"""
# --------------------------------------------------------------------------------------#

# Q 1:
"""
We want to resize the images in the "images" folder in this project.
The initial size of this folder is around 27,5 MB with 20 images in it.
We want to create a "thumbnails" folder which includes the thumbnails of these images.
Thumbnail dimensions (width * height) of each image will 1/10 of the original image.
For example, the dimensions "Fight Club.jpg" file in the "images" directory is 2021*3000 pixels,
but its thumbnail will be around 202*300 pixels.
And in terms of disk space, we expect the "thumbnails" folder to be around 200 KB.
You should keep track of elapsed time (start & end).

You need to define four functions:
* get_images
* create_directory
* resize_all_images
* resize_image

Packages you need:
* os
* pathlib
* time
* Pillow (for PIL)
"""

# Q 1:

# import packages
import os
from pathlib import Path
import time
# install Pillow package for PIL
from PIL import Image

# directory names
images_directory = "images"
thumbnails_directory = "thumbnails"

# get images fn
def get_images():
    """Returns a list of .jpg files
    in the images folder"""
    # ---- your solution here ---

# create directory fn
def create_directory(name):
    """Creates the directory with name.
    No errors if the directory exists."""
    # ---- your solution here ---

# resize all images fn
def resize_all_images():
    """Creates the directory.
    Gets images and call resize fn one by one.
    Keeps track of elapsed time."""
    try:
        # set start time
        # ---- your solution here ---
        # create directory
        # ---- your solution here ---
        # get images
        # ---- your solution here ---
        # resize each image one by one
        # ---- your solution here ---
        # set end time
        # ---- your solution here ---
    except:
        print("An Error occurred in resizing.")
    else:
        # print elapsed time
        # ---- your solution here ---

# resize a single image fn
def resize_image(image):
    # open the image
    # ---- your solution here ---
    # resize the image
    # ---- your solution here ---
    # Save the resized image
    # ---- your solution here ---
    # print result
    # ---- your solution here ---

# call resize all function
resize_all_images()


# --------------------------------------------------------------------------------------#

# Q 2:
"""
Redefine the resize_all_images() function you defined in Q1.
This time it will use Threading for resize operation.
Create and start a thread for each resize_image() function call.
Append these threads to a list called "threads".
Then join() the threads to force the code to wait them to finish.
Keep track of time again and print the final result.

Hints:
* create each thread using the Thread class
* start() each thread you create
* join() them in a separate for loop
"""

# Q 2:

from threading import Thread

# create a threads list
threads = []

# redefine resize all images fn
def resize_all_images():
    """Creates the directory.
        Gets images and call resize fn one by one.
        Keeps track of elapsed time."""
    try:
        # set start time
        # ---- your solution here ---
        # create directory
        # ---- your solution here ---
        # get images
        # ---- your solution here ---
        # fill the threads list
        # ---- your solution here ---
        # force for wait for finish
        # ---- your solution here ---
        # set end time
        # ---- your solution here ---
    except:
        print("An Error occurred in resizing.")
    else:
        # print elapsed time
        # ---- your solution here ---

# call resize all function
resize_all_images()


# --------------------------------------------------------------------------------------#

# Q 3:
"""
Redefine the resize_all_images() function you defined in Q1.
Use ThreadPoolExecutor in this question.
Set a with context manager using ThreadPoolExecutor and use list comprehension
to submit() threads.
Use a for loop to be able to get the result when the threads are completed.

Hints:
* ThreadPoolExecutor()
* [submit() in list comprehension]
* as_comleted()
* Future.result()
"""

# Q 3:

from concurrent.futures import ThreadPoolExecutor, as_completed

# create a threads list
threads = []

# redefine resize all images fn
def resize_all_images():
    """Creates the directory.
        Gets images and call resize fn one by one.
        Keeps track of elapsed time."""
    try:
        # set start time
        # ---- your solution here ---
        # create directory
        # ---- your solution here ---
        # get images
        # ---- your solution here ---
        # set ThreadPoolExecutor
        with # ---- your solution here ---:
            # submit the threads and get a list of futures
            # ---- your solution here ---
            # call as_complete() method for result
            # ---- your solution here ---
        # set end time
        # ---- your solution here ---
    except:
        print("An Error occurred in resizing.")
    else:
        # print elapsed time
        # ---- your solution here ---

# call resize all function
resize_all_images()


# --------------------------------------------------------------------------------------#

# Q 4:
"""
Redefine the resize_all_images() function you defined in Q1.
Use ProcessPoolExecutor in this question.
Set a with context manager using ProcessPoolExecutor and use list comprehension
to submit() threads.
Use a for loop to be able to get the result when the threads are completed.
Keep track of time again and print the final result.

Hints:
* ProcessPoolExecutor()
* [submit() in list comprehension]
* as_comleted()
* Future.result()
"""

# Q 4:

from concurrent.futures import ProcessPoolExecutor, as_completed

# create a threads list
threads = []

# redefine resize all images fn
def resize_all_images():
    """Creates the directory.
        Gets images and call resize fn one by one.
        Keeps track of elapsed time."""
    try:
        # set start time
        # ---- your solution here ---
        # create directory
        # ---- your solution here ---
        # get images
        # ---- your solution here ---
        # set ThreadPoolExecutor
        with # ---- your solution here ---:
            # submit the threads and get a list of futures
            # ---- your solution here ---
            # call as_complete() method for result
            # ---- your solution here ---
        # set end time
        # ---- your solution here ---
    except:
        print("An Error occurred in resizing.")
    else:
        # print elapsed time
        # ---- your solution here ---

# call resize all function
resize_all_images()


# --------------------------------------------------------------------------------------#

# Q 5:
"""
Redefine the resize_all_images() function you defined in Q1.
Use ProcessPoolExecutor with map() function in this question.
Set a with context manager using ProcessPoolExecutor and map() the threads.
Keep track of time again and print the final result.

Hints:
* ProcessPoolExecutor()
* map(function, iterable)
"""

# Q 5:

from concurrent.futures import ProcessPoolExecutor

# create a threads list
threads = []

# redefine resize all images fn
def resize_all_images():
    """Creates the directory.
        Gets images and call resize fn one by one.
        Keeps track of elapsed time."""
    try:
        # set start time
        # ---- your solution here ---
        # create directory
        # ---- your solution here ---
        # get images
        # ---- your solution here ---
        # set ThreadPoolExecutor
        with # ---- your solution here ---:
            # map the threads
            # ---- your solution here ---
        # set end time
        # ---- your solution here ---
    except:
        print("An Error occurred in resizing.")
    else:
        # print elapsed time
        # ---- your solution here ---

# call resize all function
resize_all_images()


# --------------------------------------------------------------------------------------#