# reduce() function

# import reduce() function
from functools import reduce

# define a summation function
def custom_sum(n1, n2):
    return n1 + n2

# define a list
numbers = [1, 2, 3, 4, 5]

# call reduce() function
summation_result = reduce(custom_sum, numbers)

# print the result
# print(summation_result)


# get the largest number in a list
from functools import reduce

nums = [5, 3, 12, 7, 15, 64, 19, 10]

def get_max(n_1, n_2):
    if n_1 <= n_2:
        return n_2
    else:
        return n_1

largest = reduce(get_max, nums)
print(f"The Largest is: {largest}")

