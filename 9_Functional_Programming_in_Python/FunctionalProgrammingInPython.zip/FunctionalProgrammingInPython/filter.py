# filter() function

# define a function
def is_odd(number):
    """checks if number is odd"""
    if number % 2 == 1:
        return True
    else:
        return False

# define a list to filter
integers = [-4, -3, -2, -1, 0, 1, 2, 3, 4]

# call the filter() function
odd_integers = filter(is_odd, integers)

# print the filter object
# print(odd_integers)

# print the items
# print(list(odd_integers))

# some dummy text
text = 'Lorem ipsum dolor sit amet consectetur adipiscing elit.'

# filter() function with lambda
words_with_a = filter(lambda w: 'a' in w.lower(), text.split())

# print the words with a in it
print(list(words_with_a))
