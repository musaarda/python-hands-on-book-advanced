# map() function

# syntax:
# map(function, iterable)

# define a function
def capitalize(text):
    return text.upper()

# define a list
heroes = ['batman', 'superman', 'spiderman']

# call the map() function
capital_heroes = map(capitalize, heroes)
# print(capital_heroes)

# print the items in map object
# print(list(capital_heroes))

# map() function with lambda
nums = [1, 2, 3, 4, 5]

# call the map() function
cubes = map(lambda x: x**3, nums)

# print the result
# print(list(cubes))


# Passing more than one iterable:
# map(function, iterable_1, iterable_2, iterable_3, ...)

# define two list
list_1 = [1, 2, 3, 4, 5]
list_2 = ['a', 'b', 'c', 'd', 'e']

# define a concat function
def concat(x, y):
    return str(x) + str(y)

# call the map function on them
combined_list = map(concat, list_1, list_2)
print(list(combined_list))
