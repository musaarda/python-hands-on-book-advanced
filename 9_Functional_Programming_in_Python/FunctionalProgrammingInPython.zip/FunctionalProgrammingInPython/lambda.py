# lambda function

# syntax
# lambda arguments : expression

text = 'Python Hands-On Advanced'
words = text.split()
# print(words)

# lambda function
lambda x: x.split

# assign lambda function to a variable
my_splitter_function = lambda x: x.split()

# call the function variable
words = my_splitter_function(text)
# print(words)

# multiplication with lambda function
multiply = lambda x, y: x * y
result = multiply(5, 8)
# print(result)

# power function with lambda
exponential = lambda num, pow: num**pow
print(exponential(2, 7))