"""
 QUIZ Functional Programming In Python
"""
# --------------------------------------------------------------------------------------#

# Q 1:
"""
Please explain the main concepts in Functional Programming paradigm:
* Functions are First-Class Citizens
* Pure Functions
* Functions can be Higher-Order
* Immutability
* Recursion
"""

# --------------------------------------------------------------------------------------#

# Q 2:
"""
Define a lambda function which takes one numeric parameter and checks if the given number is even or not.
Assign it to a local variable.
Finally call this variable and print the results for 17 and 18.
"""

# Q 2:

# define and assign the lambda function
# ---- your solution here ---

# call and print the result for 17 and 18.
# ---- your solution here ---

# --------------------------------------------------------------------------------------#

# Q 3:
"""
Define a map() function which takes a lambda expression and a list as arguments.
This map() will use the lambda function which we define in Q2.
We want it to return a map object that keeps True and False values for each item in the list.
If the item is even, the respective value should be True, otherwise it should be False.

The list is:
[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

And the expected result (which should be a new list):
[False, True, False, True, False, True, False, True, False, True]
"""

# Q 3:

# define the list
# ---- your solution here ---

# call the map() function
# ---- your solution here ---

# print the resulting list
# ---- your solution here ---

# --------------------------------------------------------------------------------------#

# Q 4:
"""
We have a list of numbers which we want to filter the negative ones.
Here is the list:
[4, -3, 0, -12, 9, 1, 2, -7, 8]

Define a filter() function which gives us the negative numbers in this list.
It should take a lambda function and this list as the parameters.
The filter function will return a filter object.
You should convert this filter object to a list.
Finally you should sort the list in ascending order in-place.

The resulting list should be:
[-12, -7, -3]

Hints:
* lambda
* filter()
* list()
* sort()
"""

# Q 4:

# define the list
# ---- your solution here ---

# define the filter function
# ---- your solution here ---

# convert filter object to list
# ---- your solution here ---

# sort the list
# ---- your solution here ---

# print the result
# ---- your solution here ---

# --------------------------------------------------------------------------------------#

# Q 5:
"""
Define a reduce() function which multiplies all the items in the given list.
The initial value will be 1000, which means it will start to multiply the first item with 1000.

Here is the list to multiply:
[1, 2, 3, 4]

The expected result is: 24000

Hints: 
* functools.reduce()
* lambda
"""

# Q 5:

# import reduce function
# ---- your solution here ---

# define the list
# ---- your solution here ---

# define the reduce function
# ---- your solution here ---

# print the final result
# ---- your solution here ---

# --------------------------------------------------------------------------------------#