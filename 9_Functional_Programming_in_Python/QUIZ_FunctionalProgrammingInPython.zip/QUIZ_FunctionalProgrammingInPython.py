"""
 QUIZ Functional Programming In Python
"""
# --------------------------------------------------------------------------------------#

# Q 1:
"""
Please explain the main concepts in Functional Programming paradigm:
* Functions are First-Class Citizens
* Pure Functions
* Functions can be Higher-Order
* Immutability
* Recursion
"""

# --------------------------------------------------------------------------------------#

# Q 2:
"""
Define a lambda function which takes one numeric parameter and checks if the given number is even or not.
Assign it to a local variable.
Finally call this variable and print the results for 17 and 18.
"""

# Q 2:

# define and assign the lambda function
# ---- your solution here ---

# call and print the result for 17 and 18.
# ---- your solution here ---

# --------------------------------------------------------------------------------------#

# Q 3:
"""
Define a map() function which takes a lambda expression and a list as arguments.
This map() will use the lambda function which we define in Q2.
We want it to return a map object that keeps True and False values for each item in the list.
If the item is even, the respective value should be True, otherwise it should be False.

The list is:
[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

And the expected result (which should be a new list):
[False, True, False, True, False, True, False, True, False, True]
"""

# Q 3:

# define the list
# ---- your solution here ---

# call the map() function
# ---- your solution here ---

# print the resulting list
# ---- your solution here ---

# --------------------------------------------------------------------------------------#

# Q 4:
"""
We have a list of numbers which we want to filter the negative ones.
Here is the list:
[4, -3, 0, -12, 9, 1, 2, -7, 8]

Define a filter() function which gives us the negative numbers in this list.
It should take a lambda function and this list as the parameters.
The filter function will return a filter object.
You should convert this filter object to a list.
Finally you should sort the list in ascending order in-place.

The resulting list should be:
[-12, -7, -3]

Hints:
* lambda
* filter()
* list()
* sort()
"""

# Q 4:

# define the list
# ---- your solution here ---

# define the filter function
# ---- your solution here ---

# convert filter object to list
# ---- your solution here ---

# sort the list
# ---- your solution here ---

# print the result
# ---- your solution here ---

# --------------------------------------------------------------------------------------#

# Q 5:
"""
Define a reduce() function which multiplies all the items in the given list.
The initial value will be 1000, which means it will start to multiply the first item with 1000.

Here is the list to multiply:
[1, 2, 3, 4]

The expected result is: 24000

Hints: 
* functools.reduce()
* lambda
"""

# Q 5:

# import reduce function
# ---- your solution here ---

# define the list
# ---- your solution here ---

# define the reduce function
# ---- your solution here ---

# print the final result
# ---- your solution here ---

# --------------------------------------------------------------------------------------#

# Q 6:
"""
Define a function named str_to_list.
It will take a list of strings as the parameter.
It will use the map() function to convert each string item into a list.
And it will return a list of lists.

Expected Output: 
List of strings:
['ABC', '123', 'xyz']
List of lists after function call:
[['A', 'B', 'C'], ['1', '2', '3'], ['x', 'y', 'z']]
"""

# Q 6:

# define the function
# ---- your solution here ---

# define the list
txt_list = ["ABC", "123", "xyz"]

# print the string list
print(f"List of strings:\n{txt_list}")

# call the function
list_of_lists = str_to_list(txt_list)

# print list of lists
print(f"List of lists:\n{list_of_lists}")

# --------------------------------------------------------------------------------------#

# Q 7:
"""
We have to lists as:
list_1 = [1,2,3,4,5,6,7,10]
list_2 = [0,2,1,4,7,8,9,10]

From these lists, we want to filter the same elements which are at the same indices.
We will define a function named get_common_items_at_same_indices.
It will take two lists and return a new list that contains the common elements.
Here is the expected output:
Common items at same indices: [2, 4, 10]

We will use two Python functions in our get_common_items_at_same_indices function:
1- map()
2. itertools.compress()

itertools.compress(test_list, bool_list): 
compress() function filters out all the elements from the test_list based on the True values in the bool_list.

"""

# Q 7:

# import itertools.compress
from itertools import compress
# import eq from operator
from operator import eq

# define the function
# ---- your solution here ---

# define the lists
list_1 = [1,2,3,4,5,6,7,10]
list_2 = [0,2,1,4,7,8,9,10]

# print the lists
print(f"Lists:\n{list_1}\n{list_2}\n")

# call function and get common items
common_items = get_common_items_at_same_indices(list_1, list_2)

# print common items
print(f"Common items at same indices:\n{common_items}")

