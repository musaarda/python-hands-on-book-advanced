"""
 QUIZ Generators
"""
# --------------------------------------------------------------------------------------#

# Q 1:
"""
Define a generator function that returns (yields) the list of first n positive and even integers.
Here is a sample list: 2, 4, 6, 8, 10, ...
Function name will be positive_evens and it will take one parameter, n.
This will be the upper limit in the list.

Call this function and print positive and even integers up to 20.

Hints:
* yield
* while loop
"""

# Q 1:

# define the function
# ---- your solution here ---

# get positive and even numbers up to 20
# ---- your solution here ---

# convert the generator to a list and print
# ---- your solution here ---

# --------------------------------------------------------------------------------------#

# Q 2:
"""
The Fibonacci Sequence is the series of numbers:
1, 1, 2, 3, 5, 8, 13, 21, 34, ...

The next number is found by adding up the two numbers before it:
* the 2 is found by adding the two numbers before it (1+1),
* the 3 is found by adding the two numbers before it (1+2),
* the 5 is (2+3),
* and so on!

Define a generator function which yields the Fibonacci Sequence.
Function name will be fibonnaci_generator and it takes one parameter, n.
This parameter is used to get the first n numbers in the sequence.
For example the first 9 numbers are: 1, 1, 2, 3, 5, 8, 13, 21, 34

Print the first 9 numbers by using this function.

Hints:
* yield
* for loop
"""

# Q 2:

# define the generator
# ---- your solution here ---

# get the first 9 numbers
# ---- your solution here ---

# print the numbers
# ---- your solution here ---

# --------------------------------------------------------------------------------------#

# Q 3:
"""
Define a generator function named get_squares_gen.
This function will take a list of integers as the parameter.
And it will yield the squares of each element one by one.

Call this generator function with the following list:
[1, 2, 3, 4, 5, 6]

Print the squares of items in this list.
To do this, first convert the iterator to a list.

Hints:
* yield
* for loop
* generator returns an iterator
"""

# Q 3:

# define the generator function
# ---- your solution here ---

# define a list of numbers
# ---- your solution here ---

# call the generator function
# ---- your solution here ---

# convert the iterator to a list
# ---- your solution here ---

# print squares list
# ---- your solution here ---

# --------------------------------------------------------------------------------------#

# Q 4:
"""
Define a generator expression.
This is going to be a one-line generator.
It will return an iterator which contains the cubes of elements in the numbers list.
Here is the numbers list:
[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

Convert the resulting iterator to a list.
Then print the items in this list.

Hints:
* generator expressions are very similar to list comprehensions
* generator expression returns an iterator object
"""

# Q 4:

# define a list of numbers
# ---- your solution here ---

# define the generator expression
# ---- your solution here ---

# convert the iterator to a list
# ---- your solution here ---

# print the cubes of odd numbers
# ---- your solution here ---

# --------------------------------------------------------------------------------------#

# Q 5:
"""
What is the difference between return and yield statements?
"""

# --------------------------------------------------------------------------------------#