# Generator Expression

# define a simple list
nums = [1, 2, 3, 4, 5]

# list comprehension
num_cubes = [i**3 for i in nums]

# generator expression
cubes_gen = (i**3 for i in nums)

# print both objects
# print(num_cubes)
# print(cubes_gen)

# loop over generator
# for item in cubes_gen:
#     print(item)

# generator for upper case
text = 'machine learning'
upper_gen = (l.upper() for l in text)
print(upper_gen.__next__())
print(next(upper_gen))

