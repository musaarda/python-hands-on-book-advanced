# Define a Generator

# define a generator function
def first_generator():
    print('Yielding First item')
    yield 'A'

    print('Yielding Second item')
    yield 'B'

    print('Yielding Last item')
    yield 'C'

# call the generator
# iter_obj = first_generator()

# print first item
# first_item = next(iter_obj)
# print(first_item)

# print second item
# second_item = next(iter_obj)
# print(second_item)

# print third item
# third_item = next(iter_obj)
# print(third_item)

# generator for sequence of numbers
def get_sequence_gen(max):
    for n in range(max):
        yield n

# call the function and get iterator
sequence_iter = get_sequence_gen(10)
# call the next() method
# print(sequence_iter.__next__())
# print(sequence_iter.__next__())
# print(next(sequence_iter))
# print(next(sequence_iter))
