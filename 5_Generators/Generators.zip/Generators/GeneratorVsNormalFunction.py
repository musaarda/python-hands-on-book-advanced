# Generator vs Normal Function

# import the time module
from time import time

# Normal Function
def first_n_numbers(max):
    n, numbers = 1, []
    while n <= max:
        numbers.append(n)
        n += 1
    return numbers

# call the function
start = time()
# first_n_list = first_n_numbers(99999999)
# sum_of_first_numbers = sum(first_n_list)
# print(sum_of_first_numbers)
# # elapsed time
# end = time()
# print("Elapsed Time in seconds:", end - start)


# Generator Function
def first_n_numbers_gen(max):
    n = 1
    while n <= max:
        yield n
        n += 1

# call the function
start = time()
# first_n_list = first_n_numbers_gen(99999999)
# sum_of_first_numbers = sum(first_n_list)
# print(sum_of_first_numbers)
# # elapsed time
# end = time()
# print("Elapsed Time in seconds:", end - start)
