# review.py file
from flask import (
    Blueprint, flash, g, redirect,
    render_template, request, url_for)
from werkzeug.exceptions import abort
from flaskapp.db import get_db
from .utils import login_required, get_all_reviews, \
    get_movie, get_review_from_db, get_movie_img

bp = Blueprint('review', __name__)

# reviews route
@bp.route('/reviews')
@login_required
def reviews():
    TODO - get all reviews
    # TODO - render template at 'review/reviews.html'
    # with parameters: all_reviews, get_movie_img

# create a new review
@bp.route('/<int:id>/create', methods=('GET', 'POST'))
@login_required
def create(id):
    # TODO - get movie with id

    if # TODO - check if method is POST
        # TODO - get title and body from the form
        error = None
        if not body:
            error = 'You need to add a review.'
        if error is not None:
            flash(error)
        else:
            # TODO - get db
            # TODO - insert a new review into db
            # 'INSERT INTO review (id, title, body, author_id)'
            #                 ' VALUES (?, ?, ?, ?)',

            # TODO - commit to db

            # TODO - redirect to 'review.reviews'

    # TODO - render template at 'review/create.html'
    # with parameter: movie

# get a single review
def get_review(id, check_author=True):
    # TODO - get review from db with id
    if review is None:
        abort(404, f"Post id {id} doesn't exist.")
    if check_author and review['author_id'] != g.user['id']:
        abort(403)
    return review

# update review
@bp.route('/<int:id>/update', methods=('GET', 'POST'))
@login_required
def update(id):
    # TODO - get review from db with id
    if request.method == 'POST':
        # TODO - get title and body from the form
        error = None
        if not title:
            error = 'Title is required.'
        if error is not None:
            flash(error)
        else:
            # TODO - get db
            # TODO - update the review in db
            # 'UPDATE review SET title = ?, body = ?'
            #                 ' WHERE id = ?'

            # TODO - commit to db

            # TODO - redirect to 'review.reviews'

    # TODO - render template at 'review/update.html'
    # with parameter: review

# delete review
@bp.route('/<int:id>/delete', methods=('POST',))
@login_required
def delete(id):
    # TODO - get review with id

    # TODO - get db
    # TODO - delete the review with id
    # 'DELETE FROM review WHERE id = ?'

    # TODO - commit to db

    # TODO - redirect to 'review.reviews'


