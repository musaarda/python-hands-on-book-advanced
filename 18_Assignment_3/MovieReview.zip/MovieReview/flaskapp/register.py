# register.py file
from flask import (Blueprint, flash, redirect,
                   render_template, request, session, url_for)
from flaskapp.db import get_db
from werkzeug.security import generate_password_hash
from .utils import get_user

# initialize the Blueprint object
bp = Blueprint('register', __name__, url_prefix='/')

# Register View Code
@bp.route('/register', methods=('GET', 'POST'))
def register():
    if request.method == 'POST':
        # get input fields
        username, password, fullname = get_input_fields()
        # get db
        db = # TODO - get db
        # check input fields
        error = check_input_fields(username, password, fullname)
        # check error
        if error is None:
            try:
                # TODO - insert new user into db
            except db.IntegrityError:
                error = f"User {username} is already registered."
            else:
                # TODO - clear session
                session.clear()
                session['user_id'] = get_user(username)['id']
                return # TODO - redirect to url for 'home.index'
        flash(error)
    return # TODO - render template at 'register/register.html'

# fn for getting inputs
def get_input_fields():
    username = request.form['username']
    # TODO - get password from request
    # TODO - get fullname from request
    return username, password, fullname

# fn for checking input fields
def check_input_fields(username, password, fullname):
    if not username or not password or not fullname:
        return 'Full Name, Username or Password can not be empty.'
    else:
        return None

# fn for inserting a DB row
def insert_into_db(db, username, password, fullname):
    # TODO - insert new row to db
    # "INSERT INTO user (username, password, fullname) "
    #                "VALUES (?, ?, ?)"

    # TODO - commit to db

