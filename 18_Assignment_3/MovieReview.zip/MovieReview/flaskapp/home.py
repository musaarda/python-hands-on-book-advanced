# home.py file
from flask import (Blueprint, g, render_template)
from .utils import login_required, get_all_reviews, \
    get_movies, get_review_from_db

# initialize the Blueprint object
bp = Blueprint('home', __name__, url_prefix='/')

# Index View Code
@bp.route('/', methods=['GET'])
@login_required
def index():
    # get all movies
    movies = # TODO - get movies
    # get all reviews
    all_reviews = # TODO - get all reviews
    # render index.html
    return # TODO - render template at 'home/index.html'
    # with parameters as: movies, all_reviews, get_if_reviewed

def get_if_reviewed(movie):
    review = # TODO - get review from db for the movie with 'id'
    if review is not None and g.user['id'] == review['author_id']:
        return True
    else:
        return False

