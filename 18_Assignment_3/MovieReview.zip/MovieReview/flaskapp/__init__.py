# __init__.py file

import os
from flask import Flask
from . import db, register, login, home, review

# application factory
def create_app(test_config=None):
    # TODO - create a Flask app object
    # with __name__ and instance_relative_config=True

    # configure the app
    app.config.from_mapping(
        SECRET_KEY='dev',
        DATABASE=os.path.join(app.instance_path, 'flaskapp.sqlite'),
    )

    # create the instance folder if not exists
    try:
        os.makedirs(app.instance_path)
    except OSError:
        pass

    # db registration
    # TODO - register the database

    # register Blueprints
    # register
    # login
    # home
    # review

    # TODO - create a simple test to see if it works
    # '/test'

    # TODO - return the configured Flask app object

