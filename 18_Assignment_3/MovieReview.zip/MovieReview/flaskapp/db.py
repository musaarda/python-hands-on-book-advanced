# db.py file

import sqlite3
import click
from flask import current_app, g
from flask.cli import with_appcontext

# db connection
def get_db():
    if 'db' not in g:
        g.db = # TODO - create sqlite3 connection
        g.db.row_factory = sqlite3.Row
    return g.db

# close connection
def close_db(e=None):
    db = g.pop('db', None)
    # TODO - check if connection exists and close

# initialize db
def init_db():
    db = # TODO - get db
    with current_app.open_resource('schema.sql') as f:
        # TODO - execute script on db

# command line command
# TODO - define a click command as 'init-db'
# TODO - call with_appcontext decorator
def init_db_command():
    """Clear the existing data and create new tables."""
    # TODO - initialize the db and print the result

# register functions with app instance
def init_app(app):
    # TODO - call teardown_appcontext fn to close db
    # TODO - add cli command to the app

