# hi.py file

# TODO - import Flask class from flask package

# TODO - create a Flask app

# TODO - define a root for '/hi'
def hi_flask():
    return "Hi from Flask App"

